PlayForge Labs — press / collaboration kit

Logo files
  mark-full.svg / mark-full-ondark.svg      full mark, light / dark ground
  mark-full-tight.svg / -ondark-tight.svg   cropped to the disc; use for avatars
  mark-small.svg / mark-small-ondark.svg    simplified cut for 48px and below
  lockup-stacked-*                          mark + wordmark, two lines
  lockup-inline-*                           mark + wordmark, one line
  wordmark-stacked-*                        type only
  mascot.png                                character art, alpha

Colours
  Red    #D62325
  Black  #110D0D
  White  #FFFFFF

Type
  Chakra Petch (SIL Open Font License). All supplied artwork is outlined,
  so the font is not required to use these files.

Using these
  - Use the -ondark files on dark backgrounds and the -onlight files on
    light ones. The on-dark variants carry a white ring because the black
    ring disappears on dark grounds.
  - Below 48px use the small cut; the full mark loses legibility.
  - Keep clear space of at least the cap height of FORGE on all sides.
  - Do not recolour, stretch, rotate or add effects to the mark.
